<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu principal - IFSP</title>
    <link rel="stylesheet" href="estilo.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>
<body>
<h1><font color="#FF0000">Menu Principal</font></h1>
    <div id="menu">
        
            <h3>
            <br>
            <li><a href="cadastro_fluxo_caixa.html"> Cadastro Fluxo de Caixa</a></li>
            <br>
            <li><a href="listar_fluxo_caixa.php"> Listagem de Fluxo de Caixa</a></li>
            <br>
            <li><a href="consulta_fluxo_caixa.html"> Consulta Saldo do Caixa</a></li>
            </h3>

        
    </div>
</body>
</html>