USE prova2;

INSERT INTO fluxo_caixa (data, tipo, valor, historico, cheque)
VALUES ('08/06/2022', 'Entrada', '150,49', 'Pagamento efetuado', 'Sim');

SELECT * FROM fluxo_caixa;