USE agenda02;

INSERT INTO agenda2 (nome, apelido, endereco, bairro, cidade, estado, telefone, celular, email, data_cadastro)
VALUES ('Breno Campachi', 'Xama', 'Rua Barão', 'Centro', 'Brauna', 'SP', '18996559663', '36921890', 'brenohvc27@gmail.com', '2022/09/12');

SELECT * FROM agenda2;